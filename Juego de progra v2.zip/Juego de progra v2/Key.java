import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Key here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Key extends Actor
{
    /**
     * Act - do whatever the Key wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act()
    {
       scaling2();
   
    }
    //este timer hace que solo se ejecute 1 vez xd.
    private int times3 = 1; 
    public void scaling2()
    {
    if (times3 == 1)
    {
        GreenfootImage image = getImage();
        image.scale(image.getWidth() - 75, image.getHeight() - 50);
        setImage(image);
        times3 = 0;
    }
}
}
