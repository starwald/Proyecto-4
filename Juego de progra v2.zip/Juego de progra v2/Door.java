import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Door here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Door extends Actor
{
    /**
     * Act - do whatever the Door wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act()
    {
        scaling3();
        Ganar();
    }
    private int times4 = 1;
     public void scaling3()
    {
    if (times4 == 1)
    {
        GreenfootImage image = getImage();
        image.scale(image.getWidth() - 100, image.getHeight() - 100);
        setImage(image);
        times4 = 0;
    }
    }
    public void Ganar()
    {
        MyWorld mundo = (MyWorld) getWorld();
        if (isTouching(Player1.class) && mundo.keys > 0) {
        mundo.showText("¡Ganaste!", mundo.getWidth()/2, mundo.getHeight()/2);
        Greenfoot.stop();
    }
    }
}

