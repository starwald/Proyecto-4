import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class MyWorld here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class MyWorld extends World
{

    /**
     * Constructor for objects of class MyWorld.
     * 
     */
    public int keys = 0;
    public void ContarLlaves(){
        keys += 1;
        showText("Llaves: " + keys, 40, 40);
    }
    public MyWorld()
    {    
        // Create a new world with 600x400 cells with a cell size of 1x1 pixels.
        super(900, 700, 1); 
        prepare();
        showText("Vidas: 3", 40, 15);
        showText("Llaves: " + keys, 40, 40);

    }
    
    /**
     * Prepare the world for the start of the program.
     * That is: create the initial objects and add them to the world.
     */
    private void prepare()
    {
        Player1 player1 = new Player1();
        addObject(player1,115,164);
        Key key = new Key();
        addObject(key,321,50);
        Door door = new Door();
        addObject(door,820,302);
        door.setLocation(855,311);
        door.setLocation(871,323);
        door.setLocation(829,348);
        door.setLocation(836,327);
        Enemy1 enemy1 = new Enemy1();
        addObject(enemy1,431,516);
    }
    
}
