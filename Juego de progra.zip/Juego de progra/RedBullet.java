import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class RedBullet here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class RedBullet extends Actor
{
    /**
     * Act - do whatever the RedBullet wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act()
    {
        move(8); //Velocidad de la bala
        scaler();
        stoper();
        
    }
    private double dx;
    private double dy;
    private int lifeTime = 60; 

    public RedBullet(int targetX, int targetY, int startX, int startY) {
       
        double deltaX = targetX - startX;
        double deltaY = targetY - startY;
        double length = Math.sqrt(deltaX * deltaX + deltaY * deltaY);
        dx = (deltaX / length) * 5; 
        dy = (deltaY / length) * 5;

        
        setRotation((int) Math.toDegrees(Math.atan2(deltaY, deltaX)));
    }
    
    public static int times3 = 1; 
    public void scaler()
    {
     GreenfootImage image = getImage();
        image.scale(20, 20);
        setImage(image);
    }
    
    public void stoper()
    {
    lifeTime--;
    if (lifeTime <= 0) {
            getWorld().removeObject(this);
    }
    }
}
