import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
public class Player1 extends Actor
{
    private int vidas = 3;
    public void act()
    {
    moveAround();
    scaling();
    shoot();
    keyGrab();
    
    //Sirve como cooldown para las balas, timer1 esta dentro de la clase shoot
    if (timer1 > 0) {
            timer1--;
        }
    //Detecto contacto con las balas enemigas
    EnemyBullet2 bala = (EnemyBullet2) getOneIntersectingObject(EnemyBullet2.class);
        if (bala != null) {
            getWorld().removeObject(bala);
            perderVida();
    
    
    }
    }   
    
    public void perderVida()
    {
    vidas--;
        getWorld().showText("Vidas: " + vidas, 40, 15);  // Mostrar vidas restantes

        if (vidas <= 0) {
            getWorld().showText("¡Perdiste!", getWorld().getWidth()/2, getWorld().getHeight()/2);
            Greenfoot.stop();  // Detener el juego
            }
    }
     //Contador de llaves
    public static int keys = 0;
    public void keyGrab()
    {
    Actor Key;
    Key = getOneObjectAtOffset(0,0,Key.class);
    if (Key != null)
        {
        World world;
        world = getWorld();
        world.removeObject(Key);
        MyWorld mundo = (MyWorld) getWorld();  
        mundo.ContarLlaves(); 
        }
        
    }
    //Este timer hace que solo se ejecute 1 vez.
    private int times = 1; 
    public void scaling()
    {
    if (times == 1){
        GreenfootImage image = getImage();
        image.scale(image.getWidth() - 50, image.getHeight() - 50);
        setImage(image);
        times = 0;
    }
    }
    
    public static int timer1 = 2; 
    public void shoot()
    {
     MouseInfo mouse = Greenfoot.getMouseInfo();     
    if (mouse != null && mouse.getButton() == 1 && timer1 == 0) { 
        
        int mouseX = mouse.getX();
        int mouseY = mouse.getY();
        int playerX = getX();
        int playerY = getY();

        RedBullet redBullet = new RedBullet(mouseX, mouseY, playerX, playerY);
        getWorld().addObject(redBullet, playerX, playerY);
        timer1 = 15;
        }   
        
    }
    


    
   public void moveAround()
    {
        int dx=10, dy=10;
        if(Greenfoot.isKeyDown("w")) dy--;
        if(Greenfoot.isKeyDown("s")) dy++;
        if(Greenfoot.isKeyDown("d")) dx++;
        if(Greenfoot.isKeyDown("a")) dx--;
        
        if (dy<10)
        {
            setRotation(270);
            move(4);
        }
        
        if (dy>10)
        {
            setRotation(90);
            move(4);
        }
        
        if (dx>10)
        {
            setRotation(0);
            move(4);
        }
        
        if (dx<10)
        {
            setRotation(180);
            move(4);
        }
    }
}
