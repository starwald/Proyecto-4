import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Enemy1 here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Enemy1 extends Actor
{
    /**
     * Act - do whatever the Enemy1 wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    private int shootTimer = 0;
    public void act()
    {
    
    scaling();
    
    shootTimer++;
        if (shootTimer >= 60) { // Dispara cada 60 actos (~1 segundo)
            shoot();
            shootTimer = 0;
    }   
}
    private int times = 1; 
    public void scaling()
    {
    if (times == 1){
        GreenfootImage image = getImage();
        image.scale(image.getWidth() - 50, image.getHeight() - 50);
        setImage(image);
        times = 0;
    }
    }
    public void shoot()
    {
        World world = getWorld();
        if (world == null) return; // Por si acaso

        // Obtener el jugador
        java.util.List<Player1> players = world.getObjects(Player1.class);
        if (players.isEmpty()) return;
        Player1 player = players.get(0);
        
        // Calcular dirección
        int dx = player.getX() - getX();
        int dy = player.getY() - getY();
        double angleRad = Math.atan2(dy, dx);
        int angle = (int) Math.toDegrees(angleRad);
        
        // Crear la bala y agregarla al mundo
        EnemyBullet2 bullet = new EnemyBullet2(angle);
        world.addObject(bullet, getX(), getY());
    }
   
}
