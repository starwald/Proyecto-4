import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Enemy1 here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Enemy1 extends Actor
{
    /**
     * Act - do whatever the Enemy1 wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    private int shootTimer = 0;
    private int vidas = 3;
    
    public void act()
    {
        moveAround();
    
        shootTimer++;
            if (shootTimer >= 60) // Dispara cada 60 actos (~1 segundo)
            { 
                shoot();
                shootTimer = 0;
            }  
        RedBullet bala = (RedBullet) getOneIntersectingObject(RedBullet.class);
           if (bala != null) 
           {
               getWorld().removeObject(bala);
               die();
           }
    }
    
    public void die()
    {
        vidas--;
        
        if (vidas <= 0) {
            World world;
            world = getWorld();
            world.removeObject(this);
            }
    }
    
    public void shoot()
    {
        World world = getWorld();
        if (world == null) return; // Por si acaso

        // Obtener el jugador
        java.util.List<Player1> players = world.getObjects(Player1.class);
        if (players.isEmpty()) return;
        Player1 player = players.get(0);
        
        // Calcular dirección
        int dx = player.getX() - getX();
        int dy = player.getY() - getY();
        double angleRad = Math.atan2(dy, dx);
        int angle = (int) Math.toDegrees(angleRad);
        
        // Crear; la bala y agregarla al mundo
        EnemyBullet2 bullet = new EnemyBullet2(angle);
        world.addObject(bullet, getX(), getY());
    }
    
    public void moveAround()
    {
        java.util.List<Player1> players = getWorld().getObjects(Player1.class);
        if (players.isEmpty()) return;

        Player1 player = players.get(0);
        int dx = player.getX() - getX();
        int dy = player.getY() - getY();
        double angle = Math.atan2(dy, dx);

        // Determinar dirección cardinal y cambiar imagen
        if (Math.abs(dx) > Math.abs(dy)) 
        {
            if (dx > 0) 
                {
                    setImage(rightImg);
                } 
                else 
                {
                    setImage(leftImg);
                }
        } 
            else 
            {
                if (dy > 0) 
                {
                    setImage(downImg);
                } 
                    else 
                {
                    setImage(upImg);
                }
            }

        // Mover hacia el jugador (sin rotar el actor visualmente)
        int moveX = (int) (4 * Math.cos(angle));
        int moveY = (int) (4 * Math.sin(angle));
        setLocation(getX() + moveX, getY() + moveY);

        // Retroceder si choca con una pared
        if (isTouching(pared.class)) 
        {
            setLocation(getX() - moveX, getY() - moveY);
        }
    }
    
    private static final int TARGET_W = 80;
    private static final int TARGET_H = 80;
    
    private final GreenfootImage upImg;
    private final GreenfootImage downImg;
    private final GreenfootImage rightImg;
    private final GreenfootImage leftImg;
    
    public Enemy1()
    {
        upImg = loadAndScale("enemy-up.png");
        downImg = loadAndScale("enemy.png");
        leftImg = loadAndScale("enemy-left.png");
        rightImg = loadAndScale("enemy-right.png");

        setImage(downImg);
    }
    
    private GreenfootImage loadAndScale(String fileName)
    {
        GreenfootImage img = new GreenfootImage(fileName);
        double factorW = (double) TARGET_W / img.getWidth();
        double factorH = (double) TARGET_H / img.getHeight();
        double factor = Math.min(factorW, factorH);

        int newW = (int)(img.getWidth() * factor);
        int newH = (int)(img.getHeight() * factor);
        img.scale(newW, newH);
        return img;
    }
}
