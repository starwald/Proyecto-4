import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

public class Key extends Actor
{
    private static final int TARGET_W = 50;  // Puedes ajustar según el tamaño deseado
    private static final int TARGET_H = 50;

    private final GreenfootImage keyImg;

    public Key()
    {
        keyImg = loadAndScale("key.png"); // Asegúrate que el nombre de imagen sea correcto
        setImage(keyImg);
    }

    public void act()
    {
        // Nada más que hacer aquí, ya se escaló en el constructor
    }

    private GreenfootImage loadAndScale(String fileName)
    {
        GreenfootImage img = new GreenfootImage(fileName);

        double factorW = (double) TARGET_W / img.getWidth();
        double factorH = (double) TARGET_H / img.getHeight();
        double factor = Math.min(factorW, factorH);

        int newW = (int) (img.getWidth() * factor);
        int newH = (int) (img.getHeight() * factor);

        img.scale(newW, newH);
        return img;
    }
}
