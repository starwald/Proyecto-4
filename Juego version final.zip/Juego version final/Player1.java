import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
public class Player1 extends Actor
{
    private int vidas = 3;
    public void act()
    {
    moveAround();
    shoot();
    keyGrab();
    
    //Sirve como cooldown para las balas, timer1 esta dentro de la clase shoot
    if (timer1 > 0) {
            timer1--;
        }
    //Detecto contacto con las balas enemigas
    EnemyBullet2 bala = (EnemyBullet2) getOneIntersectingObject(EnemyBullet2.class);
        if (bala != null) {
            getWorld().removeObject(bala);
            perderVida();
    }
    }   
    
    public void perderVida()
    {
        vidas--;
        getWorld().showText("Vidas: " + vidas, 40, 15);  // Mostrar vidas restantes

        if (vidas <= 0) {
            getWorld().showText("¡Perdiste!", getWorld().getWidth()/2, getWorld().getHeight()/2);
            World world;
            world = getWorld();
            world.removeObject(this);
            Greenfoot.stop();  // Detener el juego
            }
    }
     //Contador de llaves
    public static int keys = 0;
    public void keyGrab()
    {
    Actor Key;
    Key = getOneObjectAtOffset(0,0,Key.class);
    if (Key != null)
        {
        World world;
        world = getWorld();
        world.removeObject(Key);
        MyWorld mundo = (MyWorld) getWorld();  
        mundo.ContarLlaves(); 
        }
        
    }
    
    public static int timer1 = 2; 
    public void shoot()
    {
     MouseInfo mouse = Greenfoot.getMouseInfo();     
    if (mouse != null && mouse.getButton() == 1 && timer1 == 0) { 
        
        int mouseX = mouse.getX();
        int mouseY = mouse.getY();
        int playerX = getX();
        int playerY = getY();

        RedBullet redBullet = new RedBullet(mouseX, mouseY, playerX, playerY);
        getWorld().addObject(redBullet, playerX, playerY);
        timer1 = 15;
        }   
        
    }
    
   public void moveAround()
    {
        int dx=0, dy=0;
        boolean moved = false;
        if(Greenfoot.isKeyDown("w") || Greenfoot.isKeyDown("up"))
        {
            dy = -5;
            setImage(upImg);
        }
        if(Greenfoot.isKeyDown("s") || Greenfoot.isKeyDown("down"))
        {
            dy = 5;
            setImage(downImg);
        }
        if(Greenfoot.isKeyDown("d") || Greenfoot.isKeyDown("right"))
        {
            dx = 5;
            setImage(rightImg);
        }
        if(Greenfoot.isKeyDown("a") || Greenfoot.isKeyDown("left"))
        {
            dx = -5;
            setImage(leftImg);
        }
        
        if (dx != 0 || dy != 0)
        {
            int originalX = getX();
            int originalY = getY();
            setLocation(originalX + dx, originalY + dy);
            
            if (isTouching(pared.class))
            {
                setLocation(originalX, originalY);
            }
        }
    }
    
    private static final int TARGET_W = 80;
    private static final int TARGET_H = 80;
    
    private final GreenfootImage upImg;
    private final GreenfootImage downImg;
    private final GreenfootImage rightImg;
    private final GreenfootImage leftImg;
    public Player1()
    {
        upImg = loadAndScale("player-up.png");
        downImg = loadAndScale("player.png");
        rightImg = loadAndScale("player-right.png");
        leftImg = loadAndScale("player-left.png");
        
        setImage(downImg);
    }
    
    private GreenfootImage loadAndScale(String fileName)
    {
        GreenfootImage img = new GreenfootImage(fileName);
        
        double factorW = (double) TARGET_W / img.getWidth();
        double factorH = (double) TARGET_H / img.getHeight();
        double factor = Math.min(factorW, factorH);
        
        int newW = (int) (img.getWidth() * factor);
        int newH = (int) (img.getHeight() * factor);
        
        img.scale(newW, newH);
        return img;
    }
}
