import greenfoot.*; 

public class EnemyBullet2 extends Actor
{
    private int lifeTime = 60; 
    private boolean scaled = false;

    public EnemyBullet2(int angle) {
        setRotation(angle);
    }

    public void act()
    {
        move(8);
        
        if (!scaled) {
            GreenfootImage image = getImage();
            image.scale(20, 20);
            setImage(image);
            scaled = true;
        }
        
        if (isTouching(pared.class))
        {
            getWorld().removeObject(this);
            return;
        }

        lifeTime--;
        if (lifeTime <= 0 || isAtEdge()) {
            getWorld().removeObject(this);
        }
    }
}
