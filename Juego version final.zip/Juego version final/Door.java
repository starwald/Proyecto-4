import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

public class Door extends Actor
{
    private static final int TARGET_W = 100; // Ajusta el tamaño deseado
    private static final int TARGET_H = 100;

    private final GreenfootImage doorImg;

    public Door() {
        doorImg = loadAndScale("door.png"); // Asegúrate de que este nombre sea correcto
        setImage(doorImg);
    }

    public void act()
    {
        Ganar();
    }

    public void Ganar()
    {
        MyWorld mundo = (MyWorld) getWorld();
        if (isTouching(Player1.class) && mundo.keys > 0) {
            mundo.showText("¡Ganaste!", mundo.getWidth()/2, mundo.getHeight()/2);
            Greenfoot.stop();
        }
    }

    private GreenfootImage loadAndScale(String fileName)
    {
        GreenfootImage img = new GreenfootImage(fileName);

        double factorW = (double) TARGET_W / img.getWidth();
        double factorH = (double) TARGET_H / img.getHeight();
        double factor = Math.min(factorW, factorH);

        int newW = (int) (img.getWidth() * factor);
        int newH = (int) (img.getHeight() * factor);

        img.scale(newW, newH);
        return img;
    }
}
