import greenfoot.*;
import java.util.*;

public class MyWorld extends World
{
    public int keys = 0;

    private final int CELL_SIZE = 100;
    private final int MAZE_ROWS = 9;
    private final int MAZE_COLS = 13;
    private final List<int[]> pathCells = new ArrayList<>();

    public void ContarLlaves(){
        keys += 1;
        showText("Llaves: " + keys, 40, 40);
    }

    public MyWorld()
    {    
        super(1300, 900, 1);
        setBackground("background.jpg");
        generateRandomMaze();
        showText("Vidas: 3", 40, 15);
        showText("Llaves: " + keys, 40, 40);
    }

    private void generateRandomMaze()
    {
        boolean[][] visited = new boolean[MAZE_ROWS][MAZE_COLS];

        // Fill entire world with walls
        for (int row = 0; row < MAZE_ROWS; row++) 
        {
            for (int col = 0; col < MAZE_COLS; col++) 
            {
                int x = col * CELL_SIZE + CELL_SIZE / 2;
                int y = row * CELL_SIZE + CELL_SIZE / 2;
                addObject(new pared(), x, y);
            }
        }

        // Generate maze using DFS from (1,1)
        generateMazeDFS(1, 1, visited);

        // Place player
        int[] playerCell = pathCells.get(0);
        addObject(new Player1(), playerCell[1] * CELL_SIZE + CELL_SIZE / 2, playerCell[0] * CELL_SIZE + CELL_SIZE / 2);

        // Place door at the farthest reachable path
        int[] doorCell = pathCells.get(pathCells.size() - 1);
        addObject(new Door(), doorCell[1] * CELL_SIZE + CELL_SIZE / 2, doorCell[0] * CELL_SIZE + CELL_SIZE / 2);

        // Add enemy
        // Place enemy randomly on the path (not at player start or door)
        int enemyIndex;
        do 
        {
            enemyIndex = Greenfoot.getRandomNumber(pathCells.size());
        } while (enemyIndex == 0 || enemyIndex == pathCells.size() - 1); // avoid player and door

        int[] enemyCell = pathCells.get(enemyIndex);
        addObject(new Enemy1(), enemyCell[1] * CELL_SIZE + CELL_SIZE / 2, enemyCell[0] * CELL_SIZE + CELL_SIZE / 2);


        // Place key randomly on path
        int keyIndex = Greenfoot.getRandomNumber(pathCells.size());
        int[] keyCell = pathCells.get(keyIndex);
        addObject(new Key(), keyCell[1] * CELL_SIZE + CELL_SIZE / 2, keyCell[0] * CELL_SIZE + CELL_SIZE / 2);

        // ✅ Place spikes only on walls or traps (not walkable path)
        placeSpikes();
    }


    private void generateMazeDFS(int row, int col, boolean[][] visited)
    {
        visited[row][col] = true;
        removeObjects(getObjectsAt(col * CELL_SIZE + CELL_SIZE / 2, row * CELL_SIZE + CELL_SIZE / 2, pared.class));
        pathCells.add(new int[]{row, col});

        int[][] directions = { {0, -2}, {0, 2}, {-2, 0}, {2, 0} };
        List<int[]> dirList = Arrays.asList(directions);
        Collections.shuffle(dirList);
        dirList.toArray(directions);

        for (int[] dir : directions) {
            int newRow = row + dir[1];
            int newCol = col + dir[0];

            if (newRow > 0 && newRow < MAZE_ROWS && newCol > 0 && newCol < MAZE_COLS && !visited[newRow][newCol]) {
                int midRow = (row + newRow) / 2;
                int midCol = (col + newCol) / 2;
                removeObjects(getObjectsAt(midCol * CELL_SIZE + CELL_SIZE / 2, midRow * CELL_SIZE + CELL_SIZE / 2, pared.class));
                pathCells.add(new int[]{midRow, midCol});
                generateMazeDFS(newRow, newCol, visited);
            }
        }
    }

        private boolean hasAdjacentWall(int row, int col)
    {
        int[][] neighbors = { {0,-1}, {0,1}, {-1,0}, {1,0} };
        for (int[] n : neighbors) {
            int r = row + n[0];
            int c = col + n[1];
            if (r >= 0 && r < MAZE_ROWS && c >= 0 && c < MAZE_COLS) {
                List<Actor> walls = new ArrayList<>();

                walls.addAll(getObjectsAt(c * CELL_SIZE + CELL_SIZE / 2, r * CELL_SIZE + CELL_SIZE / 2, pared.class));
                walls.addAll(getObjectsAt(c * CELL_SIZE + CELL_SIZE / 2, r * CELL_SIZE + CELL_SIZE / 2, pared2.class));

                if (!walls.isEmpty()) return true;
            }
        }
        return false;
    }

    private boolean isWallOrTrap(int row, int col) 
    {
        int x = col * CELL_SIZE + CELL_SIZE / 2;
        int y = row * CELL_SIZE + CELL_SIZE / 2;
        return !getObjectsAt(x, y, pared.class).isEmpty()
            || !getObjectsAt(x, y, pared2.class).isEmpty();
    }

    private void placeSpikes() 
    {
        for (int row = 0; row < MAZE_ROWS; row++) {
            for (int col = 0; col < MAZE_COLS; col++) {
                if (isWallOrTrap(row, col)) {
                    if (Greenfoot.getRandomNumber(100) < 20) { // 20% chance to place a spike
                        int x = col * CELL_SIZE + CELL_SIZE / 2;
                        int y = row * CELL_SIZE + CELL_SIZE / 2;
                        addObject(new spikes(), x, y);
                    }
                }
            }
        }
    }

}
