import greenfoot.*;

public class spikes extends Actor {
    public spikes() {
        GreenfootImage image = getImage();
        image.scale(100, 100); // Match CELL_SIZE
        setImage(image);
    }
    
    public void act()
    {
        Player1 player = (Player1) getOneIntersectingObject(Player1.class);
        if (player != null) {
            player.perderVida();
        }
    }
}
