import greenfoot.*;

public class pared2 extends Actor {
    public pared2() {
        GreenfootImage image = getImage();
        image.scale(100, 100); // Match CELL_SIZE
        setImage(image);
    }
}
