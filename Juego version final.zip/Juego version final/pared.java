import greenfoot.*;

public class pared extends Actor {
    public pared() {
        GreenfootImage image = getImage();
        image.scale(100, 100); // Scale to match MyWorld.CELL_SIZE
        setImage(image);
    }
}
